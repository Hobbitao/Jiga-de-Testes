#include <Wire.h>
#include "MAX30105.h"
#include "heartRate.h"
#include <ArduinoJson.h>  // Biblioteca para trabalhar com JSON
#include <Arduino.h>

// Definir a comunicação serial para enviar dados via Serial1 para a Jiga
#define RX_PIN 16  // Pino RX1 (oxímetro)
#define TX_PIN 17  // Pino TX1 (oxímetro)

// Inicializar o sensor e variáveis
MAX30105 particleSensor;
const byte RATE_SIZE = 4;
byte rates[RATE_SIZE];    
byte rateSpot = 0;
long lastBeat = 0;
float beatsPerMinute;
int beatAvg;

void setup() {
  // Inicializar Serial1 para comunicação com a jiga
  Serial1.begin(115200, SERIAL_8N1, RX_PIN, TX_PIN);
  Serial.begin(115200);

  // Inicializar o sensor MAX30105
  if (!particleSensor.begin(Wire, I2C_SPEED_FAST)) {
    Serial.println("Sensor MAX30105 não encontrado.");
    while (1);
  }
  particleSensor.setup();
  particleSensor.setPulseAmplitudeRed(0x0A);
  particleSensor.setPulseAmplitudeGreen(0);
}

void loop() {
  long irValue = particleSensor.getIR();

  if (irValue > 50000 && checkForBeat(irValue)) {
    long delta = millis() - lastBeat;
    lastBeat = millis();
    beatsPerMinute = 60 / (delta / 1000.0);

    if (beatsPerMinute < 255 && beatsPerMinute > 20) {
      rates[rateSpot++] = (byte)beatsPerMinute;
      rateSpot %= RATE_SIZE;
      beatAvg = 0;
      for (byte x = 0; x < RATE_SIZE; x++) beatAvg += rates[x];
      beatAvg /= RATE_SIZE;

      // Criar objeto JSON com os dados do oxímetro
      StaticJsonDocument<200> doc;
      doc["status"] = "ok";
      doc["bpm"] = beatsPerMinute;
      doc["avg_bpm"] = beatAvg;
      doc["ir_value"] = irValue;
      doc["sensor"] = "MAX30105";

      // Enviar o JSON via Serial1 para a jiga
      String jsonStr;
      serializeJson(doc, jsonStr);
      Serial1.println(jsonStr);
    }
  }

  delay(1000);
}