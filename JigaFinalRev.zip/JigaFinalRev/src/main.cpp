#include <Arduino.h>
#include <ArduinoJson.h>  // Biblioteca para trabalhar com JSON

// Configurar comunicação serial da jiga
#define RX1_PIN 16  // Pino RX para receber dados do oxímetro
#define TX1_PIN 17  // Pino TX para enviar dados para o computador/interface
#define RX2_PIN 18  // Pino RX2 para receber dados do computador/interface (via MAX3232)
#define TX2_PIN 19  // Pino TX2 para enviar dados para o oxímetro

void setup() {
  // Inicializar comunicação serial
  Serial.begin(115200);  // Comunicação com o computador (interface gráfica)
  Serial1.begin(115200, SERIAL_8N1, RX1_PIN, TX1_PIN);  // Comunicação com o oxímetro

  Serial.println("Jiga de testes inicializada");
}

void loop() {
  // Verificar se há dados recebidos do oxímetro
  if (Serial1.available()) {
    String jsonStr = Serial1.readStringUntil('\n');

    // Transmitir o JSON para o computador via Serial (para a interface gráfica)
    Serial.println(jsonStr);
  }

  delay(100);  // Pequeno delay para evitar sobrecarga
}