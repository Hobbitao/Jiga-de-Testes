#include <stdio.h>
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "driver/i2c.h"
#include "esp_log.h"
#include "ssd1306.h"  // Biblioteca para o display OLED
//#include "font8x8_basic.h"  // Fontes para o display
// #include "max30102.h"  // Biblioteca para o sensor MAX30102 (inclua esta quando tiver disponível)

#define I2C_MASTER_SCL_IO 22        // Pino SCL
#define I2C_MASTER_SDA_IO 21        // Pino SDA
#define I2C_MASTER_NUM I2C_NUM_0    // Porta I2C
#define I2C_MASTER_FREQ_HZ 100000   // Frequência I2C
#define I2C_MASTER_TX_BUF_DISABLE 0 // Desativar buffer de transmissão
#define I2C_MASTER_RX_BUF_DISABLE 0 // Desativar buffer de recepção
#define OLED_ADDR 0x3C              // Endereço I2C do display OLED
#define MAX30102_ADDR 0x57          // Endereço I2C do sensor MAX30102

// Variáveis de log
static const char *TAG = "Oxímetro";

// Função de inicialização do I2C
static void i2c_master_init(void) {
    i2c_config_t conf = {
        .mode = I2C_MODE_MASTER,
        .sda_io_num = I2C_MASTER_SDA_IO,
        .sda_pullup_en = GPIO_PULLUP_ENABLE,
        .scl_io_num = I2C_MASTER_SCL_IO,
        .scl_pullup_en = GPIO_PULLUP_ENABLE,
        .master.clk_speed = I2C_MASTER_FREQ_HZ,
    };
    ESP_ERROR_CHECK(i2c_param_config(I2C_MASTER_NUM, &conf));
    ESP_ERROR_CHECK(i2c_driver_install(I2C_MASTER_NUM, conf.mode, I2C_MASTER_RX_BUF_DISABLE, I2C_MASTER_TX_BUF_DISABLE, 0));
}

// Função para mostrar o startup no display OLED
void oled_startup_display(void) {
    // Inicializar o display OLED
    ssd1306_init(OLED_ADDR, I2C_MASTER_NUM);

    // Limpar display
    ssd1306_clear_screen();

    // Mostrar mensagem de startup
    ssd1306_draw_string(0, 0, (uint8_t *)"Oxímetro Startup", 16, true);
    ssd1306_draw_string(0, 16, (uint8_t *)"Aguarde...", 16, true);
    ssd1306_display(); // Enviar para o display

    // Esperar 5 segundos
    vTaskDelay(5000 / portTICK_PERIOD_MS);

    // Limpar tela para o próximo passo
    ssd1306_clear_screen();
    ssd1306_draw_string(0, 0, (uint8_t *)"Iniciando leitura", 16, true);
    ssd1306_display();

    ESP_LOGI(TAG, "Display de inicialização completo.");
}


// Função para inicializar o sensor MAX30102
void max30102_init() {
    // Configuração inicial do sensor
    uint8_t config_data[] = {0x02, 0x03, 0x27}; // Exemplo de configuração (ajuste conforme o datasheet do MAX30102)
    ESP_ERROR_CHECK(i2c_master_write_to_device(I2C_MASTER_NUM, MAX30102_ADDR, config_data, sizeof(config_data), 1000 / portTICK_PERIOD_MS));

    ESP_LOGI(TAG, "MAX30102 inicializado.");
}

// Função para ler os dados de SpO2 e frequência cardíaca do sensor MAX30102
void max30102_read_data() {
    uint8_t data[6]; // Buffer para armazenar os dados lidos do sensor

    // Ler 6 bytes do registro de dados do MAX30102
    ESP_ERROR_CHECK(i2c_master_read_from_device(I2C_MASTER_NUM, MAX30102_ADDR, data, sizeof(data), 1000 / portTICK_PERIOD_MS));

    // Processar os dados (exemplo simples)
    uint32_t red_led = (data[0] << 16) | (data[1] << 8) | data[2];  // Dado do LED vermelho
    uint32_t ir_led = (data[3] << 16) | (data[4] << 8) | data[5];   // Dado do LED infravermelho

    ESP_LOGI(TAG, "Red LED: %d, IR LED: %d", red_led, ir_led);

    // Exibir no display OLED (ajuste o formato conforme necessário)
    char buffer[32];
    snprintf(buffer, sizeof(buffer), "Red: %d", red_led);
    ssd1306_draw_string(0, 0, (uint8_t *)buffer, 16, true);
    snprintf(buffer, sizeof(buffer), "IR: %d", ir_led);
    ssd1306_draw_string(0, 16, (uint8_t *)buffer, 16, true);
    ssd1306_display();
}


// Função principal
void app_main(void) {
    // Inicializar o I2C
    i2c_master_init();

    // Exibir tela de inicialização no display OLED
    oled_startup_display();

    /* 
    // Inicializar o sensor MAX30102
    max30102_init();

    // Loop de leitura dos dados do sensor MAX30102
    while (true) {
        max30102_read_data();
        vTaskDelay(1000 / portTICK_PERIOD_MS); // Aguardar 1 segundo entre leituras
    }
    */

    // Mantém o programa rodando indefinidamente
    while (true) {
        vTaskDelay(1000 / portTICK_PERIOD_MS); // Delay para manter a tarefa ativa
    }
}